package marcogaray.ittepic.edu.tpdm_u1_practica1_garay;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    //Variables globales
    Button btn;
    EditText edad;
    String edad2;
    int num;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        //Empieza
        btn = findViewById(R.id.btnveri);
        edad = findViewById(R.id.edad);
            btn.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    edad2 = edad.getText().toString();
                    num = Integer.parseInt(edad2);
                    if (num>=18){
                        Toast.makeText(MainActivity.this, "Ya puedes hacer el servicio militar", Toast.LENGTH_LONG).show();
                    }
                    else{
                        Toast.makeText(MainActivity.this, "Aun no puedes hacer el servicio militar", Toast.LENGTH_LONG).show();
                    }
                }
            });

    }
}
